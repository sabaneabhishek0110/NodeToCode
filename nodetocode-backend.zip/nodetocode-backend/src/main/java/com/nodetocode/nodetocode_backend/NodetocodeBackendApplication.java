package com.nodetocode.nodetocode_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NodetocodeBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(NodetocodeBackendApplication.class, args);
	}

}
